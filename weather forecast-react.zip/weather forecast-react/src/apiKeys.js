// Visit https://api.openweathermap.org & then signup to get our API keys for free
module.exports = {
  key: "{Your API Key Here}",
  base: "https://api.openweathermap.org/data/2.5/",
};
